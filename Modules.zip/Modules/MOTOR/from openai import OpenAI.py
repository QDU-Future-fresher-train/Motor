from openai import OpenAI

client = OpenAI(
    api_key='sk-e453dc2e2aaa4052b78c0abbcf9946d7',  # 替换为你实际的 Key
    base_url='https://api.deepseek.com'
)

try:
    response = client.chat.completions.create(
        model='deepseek-chat',
        messages=[{'role': 'user', 'content': '用一句话介绍DeepSeek'}]
    )
    print(response.choices[0].message.content)
except Exception as e:
    print('错误：', e)