#pragma once

// clang-format off
/* === MODULE MANIFEST V2 ===
module_description: IMU interface module
constructor_args: []
template_args: []
required_hardware:
  - imu
  - scl
  - sda
depends: []
=== END MANIFEST === */
// clang-format on

#include "app_framework.hpp"
 #include "app_main.h"
#include "cdc_uart.hpp"
#include "libxr.hpp"
#include "main.h"
#include "stm32_adc.hpp"
#include "stm32_can.hpp"
#include "stm32_canfd.hpp"
#include "stm32_dac.hpp"
#include "stm32_flash.hpp"
#include "stm32_gpio.hpp"
#include "stm32_i2c.hpp"
#include "stm32_power.hpp"
#include "stm32_pwm.hpp"
#include "stm32_spi.hpp"
#include "stm32_timebase.hpp"
#include "stm32_uart.hpp"
#include "stm32_usb_dev.hpp"
#include "stm32_watchdog.hpp"
#include "flash_map.hpp"
#include <algorithm>
class MOTOR : public LibXR::Application {
public:
   void canCallback(bool in_isr,const LibXR::CAN::ClassicPack &pack){
    uint16_t feedback=(static_cast<uint16_t>(pack.data[0]) << 8) | static_cast<uint16_t>(pack.data[1]);
    this->control_value=pid_calculate(pos_pid, this->control_value, feedback, 0.01f); 
    actionmotor();
    }
    
  MOTOR(LibXR::STM32CAN* hcan) {
    // Hardware initialization example:
    // auto dev = hw.template Find<LibXR::GPIO>("led");
    this->can =hcan;
    pos_pid = new PID_Controller;
    pid_init(pos_pid, 3.0f, 0.1f, 0.01f); // 示例PID参数，需根据实际情况调整
    
    can->Register( 
        LibXR::CAN::Callback([this](bool in_isr, const LibXR::CAN::ClassicPack& pack) {
                        this->canCallback(in_isr, pack);}),
  
    LibXR::CAN::Type::STANDARD,
    LibXR::CAN::FilterMode::ID_RANGE,
    0x100, 0x1FF
);
  }
~MOTOR() {
    delete pos_pid;
}; // 默认析构函数



LibXR::STM32CAN* can=NULL;
void OnMonitor() override {}


int16_t control_value=0;
void actionmotor() {
LibXR::CAN::ClassicPack pack{};
     
    pack.id = 0x1FF;          
    pack.type = LibXR::CAN::Type::STANDARD;  
    pack.data[0] = (control_value >> 8) & 0xFF; 
    pack.data[1] = control_value & 0xFF;         
    pack.data[2] = (control_value >> 8) & 0xFF;   
    pack.data[3] = control_value & 0xFF;     
    pack.data[4] = (control_value >> 8) & 0xFF;  
    pack.data[5] = control_value & 0xFF;      
    pack.data[6] = (control_value >> 8) & 0xFF; 
    pack.data[7] = control_value & 0xFF;      
    can->AddMessage(pack);
}


    
    

private:
typedef struct PID_Controller{
    // PID 参数
    float kp;          // 比例系数
    float ki;          // 积分系数
    float kd;          // 微分系数

    // 控制限幅（防止输出超量程）
    float output_max;  // 输出最大值（对应GM6020最大电压25000）
    float output_min;  // 输出最小值（对应GM6020最小电压-25000）

    // 积分限幅（防止积分饱和）
    float integral_max; // 积分项最大值
    float integral_min; // 积分项最小值

    // 积分分离阈值
    float integral_threshold;

    float error;      
    float last_error; 
    float integral;   
    float derivative;  
    float output;      
};
void pid_init(PID_Controller* pid, float kp, float ki, float kd) {
    // 基础PID参数
    pid->kp = kp;
    pid->ki = ki;
    pid->kd = kd;

    // GM6020电压输出限幅（对应-25000~25000）
    pid->output_max = 25000.0f;
    pid->output_min = -25000.0f;

    // 积分限幅（建议为输出限幅的1/5，防止积分饱和）
    pid->integral_max = 5000.0f;
    pid->integral_min = -5000.0f;

    // 积分分离阈值（误差超过该值时关闭积分，速度环建议50rpm，位置环建议100角度）
    pid->integral_threshold = 50.0f;

    // 初始化内部状态
    pid->error = 0.0f;
    pid->last_error = 0.0f;
    pid->integral = 0.0f;
    pid->derivative = 0.0f;
    pid->output = 0.0f;
}


int16_t pid_calculate(PID_Controller* pid, float set_value, float feedback_value, float dt) {
    pid->error = set_value - feedback_value;
    float p_term = pid->kp * pid->error;
    if (fabs(pid->error) < pid->integral_threshold) {
        pid->integral += pid->error * dt;
        // 积分限幅，防止饱和
        pid->integral = std::clamp(pid->integral, pid->integral_min, pid->integral_max);
    } else {
        pid->integral = 0.0f; // 误差过大，清空积分
    }
    float i_term = pid->ki * pid->integral;

    // 4. 微分项（抗微分冲击：用误差变化率，而非反馈变化率）
    pid->derivative = (pid->error - pid->last_error) / dt;
    float d_term = pid->kd * pid->derivative;

    // 5. 计算总输出并限幅
    pid->output = p_term + i_term + d_term;
    pid->output = std::clamp(pid->output, pid->output_min, pid->output_max);

    // 6. 保存当前误差为下一次的last_error
    pid->last_error = pid->error;

    // 7. 转换为16位整数（GM6020需要整数电压指令）
    return static_cast<int16_t>(pid->output);
}
public:PID_Controller* pos_pid;
void control(uint16_t set_value) {
    this->control_value=set_value;

};
};